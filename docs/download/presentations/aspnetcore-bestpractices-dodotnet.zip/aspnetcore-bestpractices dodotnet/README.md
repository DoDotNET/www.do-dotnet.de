# aspnetcore-bestpractices
A repository I use for my Usergroup/Conference talks about the topic.
