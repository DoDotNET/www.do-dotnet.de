﻿namespace AspNetCoreBestPractices.Tests
{
    using System.Threading;
    using System.Threading.Tasks;
    using Database;
    using FluentAssertions;
    using Microsoft.EntityFrameworkCore;
    using NSubstitute;
    using NUnit.Framework;

    [TestFixture]
    public class GetStarshipsRequestHandlerTest
    {
        [Test]
        public async Task It_will_simply_return_all_starships_from_database()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<StarshipsContext>()
                .UseSqlServer("Server=(localdb)\\mssqllocaldb;Database=StarshipsUnitTest")
                .Options;
            var context = new StarshipsContext(options);
            context.Database.EnsureDeleted();
            context.Database.Migrate();
            context.Starships.Add(new Starship {Name = "TestShip"});
            await context.SaveChangesAsync();
            var mailService = Substitute.For<IEmailService>();
            mailService.SendMail(Arg.Any<string>(), Arg.Any<string>())
                .Returns(true);
            var subject = new GetStarshipsRequestHandler(context, mailService);

            // Act
            var result = await subject
                .Handle(new GetStarshipsRequest(), CancellationToken.None);

            //Assert
            result.Value.Should()
                .HaveCount(1)
                .And.Contain(s => s.Name == "TestShip");
        }
    }
}
