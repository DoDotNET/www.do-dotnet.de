﻿namespace AspNetCoreBestPractices.Tests
{
    using System.Threading;
    using System.Threading.Tasks;
    using Database;
    using FluentAssertions;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.EntityFrameworkCore;
    using NUnit.Framework;

    [TestFixture]
    public class CreateStarshipRequestHandlerTest
    {
        [Test]
        public async Task It_should_create_the_passed_starship_in_database()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<StarshipsContext>()
                .UseSqlServer("Server=(localdb)\\mssqllocaldb;Database=StarshipsUnitTest")
                .Options;
            var context = new StarshipsContext(options);
            context.Database.EnsureDeleted();
            context.Database.Migrate();

            var newStarshipRequest = new CreateStarshipRequest
            {
                Manufacturer = "SomeManufacturer",
                Name = "SomeShip"
            };

            var result = await new CreateStarshipRequestHandler(context)
                .Handle(newStarshipRequest, CancellationToken.None);

            result.Should().BeOfType<OkResult>();
            var assertionContext = new StarshipsContext(options);
            var ship = await assertionContext.Starships.SingleAsync(s => s.Name == "SomeShip");
            ship.Should().BeEquivalentTo(newStarshipRequest);
        }
    }
}
