﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AspNetCoreBestPractices.Tests
{
    using FluentValidation.TestHelper;
    using NUnit.Framework;

    public class CreateStarshipRequestValidatorTest
    {
        [Test]
        public void Name_should_not_be_empty()
        {
            var validator = new CreateStarshipRequestValidator();

            validator.ShouldHaveValidationErrorFor(s => s.Name, (string) null);
        }

        [Test]
        public void Name_should_have_a_max_length()
        {
            var validator = new CreateStarshipRequestValidator();

            validator.ShouldHaveValidationErrorFor(s => 
                s.Name, new string('b', 129));
        }
    }
}
