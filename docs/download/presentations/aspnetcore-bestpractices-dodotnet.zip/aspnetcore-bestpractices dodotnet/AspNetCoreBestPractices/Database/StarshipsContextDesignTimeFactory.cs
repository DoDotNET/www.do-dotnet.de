﻿namespace AspNetCoreBestPractices.Database
{
    using Microsoft.EntityFrameworkCore;
    using Microsoft.EntityFrameworkCore.Design;

    public class StarshipsContextDesignTimeFactory : IDesignTimeDbContextFactory<StarshipsContext>
    {
        public StarshipsContext CreateDbContext(string[] args)
        {
            var options = new DbContextOptionsBuilder<StarshipsContext>()
                .UseSqlServer("Server=(localdb)\\mssqllocaldb;Database=Starships")
                .Options;

            return new StarshipsContext(options);
        }
    }
}