﻿namespace AspNetCoreBestPractices.Database
{
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    public class Starship
    {
        public int Id { get; set; }

        [Required, MaxLength(128)]
        public string Name { get; set; }

        [MaxLength(255)]
        public string Manufacturer { get; set; }

        public IList<CrewMember> CrewMembers { get; set; }
    }

    public class CrewMember
    {
        [ForeignKey(nameof(Starship))]
        public int StarshipId { get; set; }
        public Starship Starship { get; set; }
        public int Id { get; set; }
        public string Name { get; set; }

        public Address Address { get; set; }
    }

    public class Address
    {
        public string City { get; set; }
        public string ZipCode { get; set; }
    }
}