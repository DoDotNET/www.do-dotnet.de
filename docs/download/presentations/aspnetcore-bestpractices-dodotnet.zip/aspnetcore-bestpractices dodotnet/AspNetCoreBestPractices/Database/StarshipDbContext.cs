﻿namespace AspNetCoreBestPractices.Database
{
    using Microsoft.EntityFrameworkCore;
    using Microsoft.EntityFrameworkCore.Metadata.Builders;

    public class StarshipsContext : DbContext
    {
        public StarshipsContext(DbContextOptions<StarshipsContext> options) : base(options)
        {

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
        }

        public DbSet<Starship> Starships { get; set; }
        public DbSet<CrewMember> CrewMembers { get; set; }
    }

    public class CrewMemberEntityConfiguration : IEntityTypeConfiguration<CrewMember>
    {
        public void Configure(EntityTypeBuilder<CrewMember> builder)
        {
            builder.OwnsOne(s => s.Address);
        }
    }
}
