﻿namespace AspNetCoreBestPractices
{
    using System.Collections.Generic;
    using System.Threading;
    using System.Threading.Tasks;
    using Database;
    using MediatR;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.EntityFrameworkCore;

    public class GetStarshipsRequestHandler : IRequestHandler<GetStarshipsRequest, ActionResult<List<Starship>>>
    {
        private readonly StarshipsContext _context;
        private readonly IEmailService _emailService;

        public GetStarshipsRequestHandler(StarshipsContext context, IEmailService emailService)
        {
            _context = context;
            _emailService = emailService;
        }

        public async Task<ActionResult<List<Starship>>> Handle(GetStarshipsRequest request, CancellationToken cancellationToken)
        {
            return await _context.Starships.ToListAsync(cancellationToken: cancellationToken);
        }
    }

    public interface IEmailService
    {
        bool SendMail(string address, string context);
    }
}