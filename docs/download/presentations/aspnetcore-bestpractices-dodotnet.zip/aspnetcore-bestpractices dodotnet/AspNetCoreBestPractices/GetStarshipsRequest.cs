﻿namespace AspNetCoreBestPractices
{
    using System.Collections.Generic;
    using Database;
    using MediatR;
    using Microsoft.AspNetCore.Mvc;

    public class GetStarshipsRequest : IRequest<ActionResult<List<Starship>>>
    {
    }
}