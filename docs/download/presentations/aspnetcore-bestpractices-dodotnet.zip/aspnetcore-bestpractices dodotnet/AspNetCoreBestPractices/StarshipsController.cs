﻿namespace AspNetCoreBestPractices
{
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Threading;
    using System.Threading.Tasks;
    using Database;
    using FluentValidation;
    using MediatR;
    using Microsoft.AspNetCore.Mvc;

    [Route("[controller]")]
    [ApiController]
    public class StarshipsController : ControllerBase
    {
        private readonly IMediator _mediator;

        public StarshipsController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpGet]
        // GET /starships
        public async Task<ActionResult<List<Starship>>> GetAllStarships()
        {
            var request = new GetStarshipsRequest();
            return await _mediator.Send(request);
        }

        [HttpPost]
        // POST /starships
        public async Task<IActionResult> CreateStarship(CreateStarshipRequest request)
        {
            return await _mediator.Send(request);
        }

        [HttpPut("{id}/crewmembers")]
        public async Task<IActionResult> AddCrewmember(AddCrewmemberRequest request)
        {

        }
    }

    public class AddCrewmemberRequest
    {
    }

    public class CreateStarshipRequest : IRequest<IActionResult>
    {
        public string Name { get; set; }
        public string Manufacturer { get; set; }
    }

    public class CreateStarshipRequestValidator : AbstractValidator<CreateStarshipRequest>
    {
        public CreateStarshipRequestValidator()
        {
            RuleFor(s => s.Name).NotNull();
            RuleFor(s => s.Name).MaximumLength(128);
        }
    }

    public class CreateStarshipRequestHandler : IRequestHandler<CreateStarshipRequest, IActionResult>
    {
        private readonly StarshipsContext _context;

        public CreateStarshipRequestHandler(StarshipsContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Handle(CreateStarshipRequest request, CancellationToken cancellationToken)
        {
            var newStarship = new Starship
            {
                Name = request.Name,
                Manufacturer = request.Manufacturer
            };
            _context.Starships.Add(newStarship);
            await _context.SaveChangesAsync(cancellationToken);
            return new OkResult();
        }
    }
}
